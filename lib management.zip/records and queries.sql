INSERT INTO members VALUES
(1, 'Suresh', 'Student', '2026-01-01'),
(2, 'Ramesh', 'Student', '2026-01-02'),
(3, 'Mahesh', 'Faculty', '2026-01-03'),
(4, 'Kumar', 'Student', '2026-01-04'),
(5, 'Arun', 'Faculty', '2026-01-05'),
(6, 'Ravi', 'Student', '2026-01-06'),
(7, 'Manoj', 'Student', '2026-01-07'),
(8, 'Priya', 'Faculty', '2026-01-08'),
(9, 'Anil', 'Student', '2026-01-09'),
(10, 'Sneha', 'Faculty', '2026-01-10');

INSERT INTO books VALUES
(101, 'Java Programming', 'James', 'Education', 400, 5),
(102, 'Python Basics', 'Guido', 'Education', 350, 4),
(103, 'DBMS', 'Korth', 'Technology', 450, 6),
(104, 'C Programming', 'Dennis', 'Education', 300, 3),
(105, 'Computer Networks', 'Andrew', 'Technology', 500, 5),
(106, 'Operating System', 'Galvin', 'Technology', 550, 4),
(107, 'HTML Basics', 'Tim', 'Technology', 250, 7),
(108, 'Web Design', 'Jon', 'Education', 400, 3),
(109, 'Data Structures', 'Mark', 'Technology', 450, 5),
(110, 'SQL Guide', 'John', 'Education', 350, 6);

INSERT INTO issues VALUES
(1, 1, 101, '2026-02-01', '2026-02-10', NULL),
(2, 2, 102, '2026-02-02', '2026-02-11', NULL),
(3, 3, 103, '2026-02-03', '2026-02-12', '2026-02-10'),
(4, 4, 104, '2026-02-04', '2026-02-13', NULL),
(5, 5, 105, '2026-02-05', '2026-02-14', '2026-02-12'),
(6, 6, 106, '2026-02-06', '2026-02-15', NULL),
(7, 7, 107, '2026-02-07', '2026-02-16', NULL),
(8, 8, 108, '2026-02-08', '2026-02-17', '2026-02-15'),
(9, 9, 109, '2026-02-09', '2026-02-18', NULL),
(10, 10, 110, '2026-02-10', '2026-02-19', '2026-02-17');

-- c2
SELECT COUNT(*) AS total_members FROM members;

SELECT COUNT(*) AS total_books FROM books;

SELECT COUNT(*) AS total_issues FROM issues;

-- c3
SELECT category,
COUNT(*) AS total_titles,
SUM(copies_available) AS total_copies
FROM books
GROUP BY category;

-- c4
SELECT books.title,
COUNT(issues.book_id) AS total_borrowed
FROM books
JOIN issues
ON books.book_id = issues.book_id
GROUP BY books.book_id, books.title
ORDER BY total_borrowed DESC
LIMIT 5;

-- c5

SELECT members.member_id, members.member_name
FROM members
LEFT JOIN issues
ON members.member_id = issues.member_id
WHERE issues.issue_id IS NULL;


-- c6

SELECT members.member_name,
books.title,
issues.due_date
FROM issues
JOIN members
ON issues.member_id = members.member_id
JOIN books
ON issues.book_id = books.book_id
WHERE issues.return_date IS NULL;

-- c7

SELECT books.title,
members.member_name,
issues.due_date,
issues.return_date,
DATEDIFF(issues.return_date, issues.due_date) AS days_late,
DATEDIFF(issues.return_date, issues.due_date) * 2 AS fine
FROM issues
JOIN books
ON issues.book_id = books.book_id
JOIN members
ON issues.member_id = members.member_id
WHERE issues.return_date > issues.due_date;

-- c8

SELECT members.member_name,
SUM(DATEDIFF(issues.return_date, issues.due_date) * 2) AS total_fine
FROM members
JOIN issues
ON members.member_id = issues.member_id
WHERE issues.return_date > issues.due_date
GROUP BY members.member_id, members.member_name
HAVING total_fine > 0;

-- c9

SELECT members.member_type,
COUNT(issues.issue_id) AS total_books_borrowed
FROM members
JOIN issues
ON members.member_id = issues.member_id
GROUP BY members.member_type;

-- c10

SELECT member_name,
total_books,
RANK() OVER (ORDER BY total_books DESC) AS member_rank
FROM (
    SELECT members.member_name,
    COUNT(issues.issue_id) AS total_books
    FROM members
    LEFT JOIN issues
    ON members.member_id = issues.member_id
    GROUP BY members.member_id, members.member_name
) AS result;

-- c11

SELECT books.category,
COUNT(issues.issue_id) AS total_issues
FROM books
JOIN issues
ON books.book_id = issues.book_id
GROUP BY books.category
ORDER BY total_issues DESC;

-- c12

SELECT title
FROM books
WHERE copies_available = 0
AND book_id IN (
    SELECT book_id
    FROM issues
    WHERE return_date IS NULL
);

